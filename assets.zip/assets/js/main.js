
let year = +prompt('Tug`ilgan yilingizni kiritin');
 let now = 2022;
let age = now - year;

console.log(`Siznimg yoshingiz ${age}`);

let month = +prompt(`tugilgan oyingizning raqamini yozing..`)

let x = month

let oy = [
  'not',
  'yanavr oyi',
  'fevral oyi',
  'mart oyi',
  'aprel oyi',
  'may oyi',
  'iyun oyi',
  'iyul oyi',
  'avgust oyi',
  'sentyabr oyi',
  'oktabr oyi',
  'noyabr oyi',
  'dekabr oyi'
];

console.log(`Siz tugilgan oy ${oy[x]}`);


